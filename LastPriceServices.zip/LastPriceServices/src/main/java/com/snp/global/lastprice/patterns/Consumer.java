package com.snp.global.lastprice.patterns;

import java.util.List;

import com.snp.global.lastprice.service.LastPriceService;

/**
 * CONSUMER: Queries last prices anytime
 */
public class Consumer {
    private final LastPriceService service;
    
    public Consumer(LastPriceService service) {
        this.service = service;
    }
    
    /**
     * REQUIREMENT: Consumer gets last price by id
     */
    public PriceRecord getLast(String id) {
        PriceRecord price = service.getLastPrice(id);
        if (price != null) {
            System.out.printf("    %s: $%.2f @ %s%n", 
                id, (Double)price.getPayload().get("price"), price.getAsOf());
        } else {
            System.out.printf("    %s: not found%n", id);
        }
        return price;
    }
    
    public void queryBatch(List<String> ids) {
        System.out.println("  Querying " + ids.size() + " instruments:");
        for (String id : ids) {
            getLast(id);
        }
    }
}
