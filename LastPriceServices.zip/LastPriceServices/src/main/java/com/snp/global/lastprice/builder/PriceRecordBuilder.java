package com.snp.global.lastprice.builder;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.snp.global.lastprice.patterns.PriceRecord;

/**
 * BUILDER PATTERN: Fluent immutable PriceRecord construction
 * 
 * Usage:
 * PriceRecord record = PriceRecord.builder()
 *     .id("AAPL")
 *     .asOf(Instant.now())
 *     .price(185.25)
 *     .volume(123456L)
 *     .build();
 */
public class PriceRecordBuilder {
    private String id;
    private Instant asOf;
    private final Map<String, Object> payload = new HashMap<>();

    public PriceRecordBuilder() {}

    public PriceRecordBuilder id(String id) {
        this.id = id;
        return this;
    }

    public PriceRecordBuilder asOf(Instant asOf) {
        this.asOf = asOf;
        return this;
    }

    public PriceRecordBuilder price(double price) {
        payload.put("price", price);
        return this;
    }

    public PriceRecordBuilder volume(long volume) {
        payload.put("volume", volume);
        return this;
    }

    public PriceRecordBuilder bid(double bid) {
        payload.put("bid", bid);
        return this;
    }

    public PriceRecordBuilder ask(double ask) {
        payload.put("ask", ask);
        return this;
    }

    public PriceRecordBuilder payload(Map<String, Object> additional) {
        payload.putAll(additional);
        return this;
    }

    public PriceRecord build() {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalStateException("id is required");
        }
        if (asOf == null) {
            throw new IllegalStateException("asOf is required");
        }
        return new PriceRecord(id, asOf, new HashMap<>(payload));
    }
}

