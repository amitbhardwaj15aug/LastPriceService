package com.snp.global.lastprice.exception;

/**
 * Thrown when chunk exceeds 1000 records
 */
public class ChunkSizeExceededException extends LastPriceServiceException {
    
    private static final int MAX_CHUNK_SIZE = 1000;
    private final int actualSize;
    
    public ChunkSizeExceededException(int actualSize) {
        super(String.format("Chunk size %d exceeds maximum %d", actualSize, MAX_CHUNK_SIZE));
        this.actualSize = actualSize;
    }
    
    public int getActualSize() {
        return actualSize;
    }
    
    public int getMaxSize() {
        return MAX_CHUNK_SIZE;
    }
}