package com.snp.global.lastprice.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.snp.global.lastprice.exception.BatchNotFoundException;
import com.snp.global.lastprice.exception.ChunkSizeExceededException;
import com.snp.global.lastprice.exception.LastPriceServiceException;
import com.snp.global.lastprice.patterns.PriceRecord;

/**
 * Core implementation using Template Method for batch processing.
 */
/**
 * In-memory implementation - Thread-safe & Atomic
 */
public class InMemoryLastPriceService implements LastPriceService {
    
    // Committed prices (visible to consumers)
    private final Map<String, PriceRecord> committed = new ConcurrentHashMap<>();
    
    // Active batches (invisible until complete)
    private final Map<UUID, List<PriceRecord>> batches = new ConcurrentHashMap<>();
    
    // Atomic batch completion
    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();

    @Override
    public UUID startBatch() {
        UUID batchId = UUID.randomUUID();
        batches.put(batchId, new ArrayList<>());
        return batchId;
    }

    @Override
    public void uploadChunk(UUID batchId, List<PriceRecord> records) {
    	Objects.requireNonNull(batchId, "batchId cannot be null");
        Objects.requireNonNull(records, "records cannot be null");
        
        if (records.size() > 1000) {
            throw new ChunkSizeExceededException(records.size()); // 🔥 NEW
        }
        
        List<PriceRecord> batchRecords = batches.get(batchId);
        if (batchRecords == null) {
            throw new BatchNotFoundException(batchId); // 🔥 NEW
        }
        batchRecords.addAll(records);
    }

    @Override
    public void completeBatch(UUID batchId) {
        rwLock.writeLock().lock();
        try {
            List<PriceRecord> batchRecords = batches.remove(batchId);
            if (batchRecords == null) {
                throw new BatchNotFoundException(batchId); // 🔥 NEW
            }
            
            // ATOMIC: Apply entire batch or none
            for (PriceRecord record : batchRecords) {
                PriceRecord existing = committed.get(record.getId());
                if (existing == null || record.getAsOf().isAfter(existing.getAsOf())) {
                    committed.put(record.getId(), record);
                }
            }
        } finally {
            rwLock.writeLock().unlock();
        }
    }

    @Override
    public void cancelBatch(UUID batchId) {
    	Objects.requireNonNull(batchId, "batchId cannot be null");
        batches.remove(batchId);
    }

    @Override
    public PriceRecord getLastPrice(String id) {
    	if (id == null || id.trim().isEmpty()) {
            throw new LastPriceServiceException("Instrument ID cannot be null or empty");
        }
        rwLock.readLock().lock();
        try {
            return committed.get(id);
        } finally {
            rwLock.readLock().unlock();
        }
    }
}
