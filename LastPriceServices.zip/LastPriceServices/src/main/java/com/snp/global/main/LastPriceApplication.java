package com.snp.global.main;


import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.snp.global.lastprice.factory.PriceRecordBuilderFactory;
import com.snp.global.lastprice.patterns.Consumer;
import com.snp.global.lastprice.patterns.PriceRecord;
import com.snp.global.lastprice.patterns.Producer;
import com.snp.global.lastprice.service.InMemoryLastPriceService;
import com.snp.global.lastprice.service.LastPriceService;


/**
 * LIVE DEMO: Producer → Service → Consumer
 * Tests ALL business requirements explicitly
 */
public class LastPriceApplication {
	public static void main(String[] args) {
        System.out.println("=== PRODUCER + CONSUMER + BUILDER DEMO ===\n");
        
        LastPriceService service = new InMemoryLastPriceService();
        Producer producer = new Producer(service);
        Consumer consumer = new Consumer(service);
        
        // ========================================
        // REQUIREMENT: PRODUCER BATCH WORKFLOW
        // ========================================
        System.out.println("📤 REQUIREMENT 1-3: PRODUCER BATCH SEQUENCE");
        System.out.println("─────────────────────────────────────────");
        
        // Step 1: Producer starts batch
        List<PriceRecord> batchRecords = createLargeBatch(2500); // >1000 forces chunks
        UUID batchId = producer.publishBatch(batchRecords);
        System.out.println("Batch id="+batchId.toString());
        
        // ========================================
        // REQUIREMENT: CONSUMER QUERIES (DURING/AFTER)
        // ========================================
        System.out.println("👁️  REQUIREMENT: CONSUMER QUERIES");
        System.out.println("─────────────────────────────────");
        consumer.queryBatch(Arrays.asList("AAPL", "GOOG", "INVALID"));
        System.out.println();
        
        // ========================================
        // REQUIREMENT: asOf DETERMINES LAST VALUE
        // ========================================
        System.out.println("⏰ REQUIREMENT: LAST BY asOf TIMESTAMP");
        System.out.println("─────────────────────────────────────");
        producer.publishUpdate("AAPL", Instant.now().minusSeconds(3600), 180.0);  // OLDER
        producer.publishUpdate("AAPL", Instant.now(), 187.75);                     // NEWER
        consumer.getLast("AAPL"); // Shows NEWER wins ✓
        System.out.println();
        
        // ========================================
        // REQUIREMENT: CANCELLED BATCHES DISCARDED
        // ========================================
        System.out.println("🗑️  REQUIREMENT: CANCELLED = INVISIBLE");
        System.out.println("────────────────────────────────────");
        UUID cancelBatch = producer.startBatch();
        producer.uploadChunk(cancelBatch, createRecords("CANCELLED_STOCK", 1));
        producer.cancelBatch(cancelBatch);
        consumer.getLast("CANCELLED_STOCK"); // not found ✓
        System.out.println();
        
        // ========================================
        // REQUIREMENT: RESILIENT TO BAD ORDER
        // ========================================
        System.out.println("🛡️  REQUIREMENT: RESILIENT TO ERRORS");
        System.out.println("───────────────────────────────────");
        testResilience(service, producer);
        System.out.println();
        
        System.out.println("🎉 ALL BUSINESS REQUIREMENTS DEMONSTRATED ✓");
    }
    
    // Producer helper methods (encapsulates workflow)
    private static List<PriceRecord> createLargeBatch(int totalRecords) {
        List<PriceRecord> records = new ArrayList<>();
        Instant baseTime = Instant.now();
        for (int i = 0; i < totalRecords; i++) {
            records.add(PriceRecordBuilderFactory.builder()
                .id(i % 3 == 0 ? "AAPL" : i % 3 == 1 ? "GOOG" : "MSFT")
                .asOf(baseTime.plusSeconds(i))
                .price(100 + i * 0.1)
                .build());
        }
        return records;
    }
    
    private static List<PriceRecord> createRecords(String symbol, int count) {
        List<PriceRecord> records = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            records.add(PriceRecordBuilderFactory.builder()
                .id(symbol)
                .asOf(Instant.now())
                .price(100 + i)
                .build());
        }
        return records;
    }
    
    private static void testResilience(LastPriceService service, Producer producer) {
        UUID fakeId = UUID.randomUUID();
        try {
            producer.uploadChunk(fakeId, Arrays.asList(PriceRecordBuilderFactory.builder().id("BAD").build()));
        } catch (Exception e) {
            System.out.println("✅ PASSED: Unknown batch rejected");
        }
        
        UUID realId = producer.startBatch();
        producer.completeBatch(realId);
        try {
            producer.uploadChunk(realId, Arrays.asList(PriceRecordBuilderFactory.builder().id("BAD2").build()));
        } catch (Exception e) {
            System.out.println("✅ PASSED: Post-complete rejected");
        }
    }
}