package com.snp.global.lastprice.exception;

/**
 * Root exception for Last Price Service
 * All service exceptions extend this class
 */
public class LastPriceServiceException extends RuntimeException {
    
    public LastPriceServiceException(String message) {
        super(message);
    }
    
    public LastPriceServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
