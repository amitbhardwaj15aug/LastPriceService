package com.snp.global.lastprice.patterns;

import java.time.Instant;
import java.util.Map;

/**
 * Immutable PriceRecord using Builder pattern.
 */
public final class PriceRecord {
	private final String id;
	private final Instant asOf;
	private final Map<String, Object> payload;

	public PriceRecord(String id, Instant asOf, Map<String, Object> payload) {
		this.id = id;
		this.asOf = asOf;
		this.payload = payload;
	}

	public String getId() {
		return id;
	}

	public Instant getAsOf() {
		return asOf;
	}

	public Map<String, Object> getPayload() {
		return payload;
	}

	@Override
	public String toString() {
		return String.format("PriceRecord{id=%s, asOf=%s, price=%s}", id, asOf, payload.get("price"));
	}

}
