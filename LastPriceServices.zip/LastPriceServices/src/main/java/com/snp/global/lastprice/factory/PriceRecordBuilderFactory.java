package com.snp.global.lastprice.factory;

import com.snp.global.lastprice.builder.PriceRecordBuilder;

/**
 * abstract FACTORY class to get instance of all the classes if defined
 */
public abstract class PriceRecordBuilderFactory {

	// BUILDER FACTORY METHOD
	public static PriceRecordBuilder builder() {
		return new PriceRecordBuilder();
	}
}
