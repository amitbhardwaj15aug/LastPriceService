package com.snp.global.lastprice.exception;

import java.util.UUID;

/**
 * Thrown when batchId doesn't exist
 */
public class BatchNotFoundException extends LastPriceServiceException {
    
    private final UUID batchId;
    
    public BatchNotFoundException(UUID batchId) {
        super(String.format("Batch not found: %s", batchId));
        this.batchId = batchId;
    }
    
    public UUID getBatchId() {
        return batchId;
    }
}