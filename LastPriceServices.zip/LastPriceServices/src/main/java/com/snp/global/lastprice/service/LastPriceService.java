package com.snp.global.lastprice.service;

import java.util.List;
import java.util.UUID;

import com.snp.global.lastprice.patterns.PriceRecord;

/**
 * Java API Interface - Producers & Consumers in same JVM
 */
public interface LastPriceService {
    /**
     * Producer: Step 1 - Start batch run
     */
    UUID startBatch();
    
    /**
     * Producer: Step 2 - Upload chunk (≤1000 records)
     */
    void uploadChunk(UUID batchId, List<PriceRecord> records);
    
    /**
     * Producer: Step 3 - Complete batch (atomic visibility)
     */
    void completeBatch(UUID batchId);
    
    /**
     * Producer: Step 3 - Discard batch
     */
    void cancelBatch(UUID batchId);
    
    /**
     * Consumer: Get last price by asOf timestamp
     */
    PriceRecord getLastPrice(String instrumentId);
}
