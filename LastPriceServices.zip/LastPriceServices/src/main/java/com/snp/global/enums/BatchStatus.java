package com.snp.global.enums;

/**
 * Possible states of a batch.
 */
public enum BatchStatus {
    STARTED,    // Can accept uploads
    COMPLETED,  // Applied to committed store, cannot be modified
    CANCELLED   // Discarded, cannot be modified
}