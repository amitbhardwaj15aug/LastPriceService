package com.snp.global.lastprice.exception;

import java.util.UUID;

/**
 * Thrown when operating on completed batch
 */
public class BatchAlreadyCompletedException extends LastPriceServiceException {
    
    private final UUID batchId;
    
    public BatchAlreadyCompletedException(UUID batchId) {
        super(String.format("Batch already completed: %s", batchId));
        this.batchId = batchId;
    }
    
    public UUID getBatchId() {
        return batchId;
    }
}
