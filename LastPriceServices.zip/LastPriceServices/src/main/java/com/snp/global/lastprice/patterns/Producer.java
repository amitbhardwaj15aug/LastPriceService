package com.snp.global.lastprice.patterns;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.snp.global.lastprice.exception.LastPriceServiceException;
import com.snp.global.lastprice.factory.PriceRecordBuilderFactory;
import com.snp.global.lastprice.service.LastPriceService;

/**
 * PRODUCER: Implements exact batch workflow from requirements
 */
public class Producer {
	private final LastPriceService service;

	public Producer(LastPriceService service) {
		this.service = service;
	}

	/**
	 * REQUIREMENT 1-3: Complete producer workflow 1. startBatch() 2. uploadChunk()
	 * x N (≤1000 each) 3. completeBatch()
	 */
	public UUID publishBatch(List<PriceRecord> allRecords) {
		System.out.println("  1️⃣ startBatch()");
		try {
	        UUID batchId = service.startBatch();
	        List<List<PriceRecord>> chunks = splitChunks(allRecords, 1000);
	        for (List<PriceRecord> chunk : chunks) {
	            service.uploadChunk(batchId, chunk);
	        }
	        service.completeBatch(batchId);
	        return batchId;
	    } catch (LastPriceServiceException e) {
	        throw new RuntimeException("Failed to publish batch", e);
	    }
	}

	public void publishUpdate(String symbol, Instant asOf, double price) {
		UUID batchId = service.startBatch();
		service.uploadChunk(batchId, Arrays.asList(PriceRecordBuilderFactory.builder().id(symbol).asOf(asOf) // ✅
																												// CRITICAL
				.price(price).build()));
		service.completeBatch(batchId);
	}

	public UUID startBatch() {
		return service.startBatch();
	}

	public void uploadChunk(UUID batchId, List<PriceRecord> chunk) {
		service.uploadChunk(batchId, chunk);
	}

	public void completeBatch(UUID batchId) {
		service.completeBatch(batchId);
	}

	public void cancelBatch(UUID batchId) {
		service.cancelBatch(batchId);
	}

	private List<List<PriceRecord>> splitChunks(List<PriceRecord> records, int maxSize) {
		List<List<PriceRecord>> chunks = new ArrayList<>();
		for (int i = 0; i < records.size(); i += maxSize) {
			chunks.add(records.subList(i, Math.min(i + maxSize, records.size())));
		}
		return chunks;
	}
}