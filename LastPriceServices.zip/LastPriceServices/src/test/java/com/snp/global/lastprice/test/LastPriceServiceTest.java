package com.snp.global.lastprice.test;
import org.junit.Before;
import org.junit.Test;

import com.snp.global.lastprice.exception.BatchNotFoundException;
import com.snp.global.lastprice.exception.ChunkSizeExceededException;
import com.snp.global.lastprice.factory.PriceRecordBuilderFactory;
import com.snp.global.lastprice.patterns.Consumer;
import com.snp.global.lastprice.patterns.PriceRecord;
import com.snp.global.lastprice.patterns.Producer;
import com.snp.global.lastprice.service.InMemoryLastPriceService;
import com.snp.global.lastprice.service.LastPriceService;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class LastPriceServiceTest {
    
    private LastPriceService service;
    private Producer producer;
    private Consumer consumer;
    
    @Before
    public void setUp() {
        service = new InMemoryLastPriceService();
        producer = new Producer(service);
        consumer = new Consumer(service);
    }
    
    // 🔥 FIXED: Correct expected values
    @Test
    public void testProducerBatchWorkflow() {
        List<PriceRecord> records = createTestRecords(1500);
        producer.publishBatch(records);
        
        // Latest asOf values: last 3 records win
        assertEquals(1497.0, service.getLastPrice("AAPL").getPayload().get("price"));
        assertEquals(1498.0, service.getLastPrice("GOOG").getPayload().get("price"));
        assertEquals(1499.0, service.getLastPrice("MSFT").getPayload().get("price"));
    }
    
    // 🔥 FIXED: Correct expected values
    @Test
    public void testConsumerMultipleQueries() {
        producer.publishBatch(createTestRecords(6));
        
        PriceRecord aapl = consumer.getLast("AAPL");
        PriceRecord goog = consumer.getLast("GOOG");
        PriceRecord msft = consumer.getLast("MSFT");
        
        assertNotNull(aapl);
        assertNotNull(goog);
        assertNotNull(msft);
        // Latest asOf: indices 3,4,5
        assertEquals(3.0, aapl.getPayload().get("price"));
        assertEquals(4.0, goog.getPayload().get("price"));
        assertEquals(5.0, msft.getPayload().get("price"));
    }
    
    // Consumer tests (unchanged)
    @Test
    public void testConsumerBasicQuery() {
        producer.publishBatch(createTestRecords(1));
        PriceRecord result = consumer.getLast("AAPL");
        assertNotNull(result);
        assertEquals("AAPL", result.getId());
    }
    
    @Test
    public void testConsumerUnknownInstrument() {
        assertNull(consumer.getLast("NONEXISTENT"));
    }
    
    @Test
    public void testConsumerDuringActiveBatch() {
        UUID batchId = producer.startBatch();
        producer.uploadChunk(batchId, createTestRecords(1));
        assertNull(consumer.getLast("AAPL"));
        producer.completeBatch(batchId);
        assertNotNull(consumer.getLast("AAPL"));
    }
    
    @Test
    public void testConsumerBatchQuery() {
        producer.publishBatch(createTestRecords(6));
        assertNotNull(service.getLastPrice("AAPL"));
        assertNotNull(service.getLastPrice("GOOG"));
        assertNotNull(service.getLastPrice("MSFT"));
    }
    
    // Other tests (unchanged)
    @Test(expected = ChunkSizeExceededException.class)
    public void testChunkSizeLimit() {
        UUID batchId = producer.startBatch();
        List<PriceRecord> bigChunk = createTestRecords(1001);
        producer.uploadChunk(batchId, bigChunk);
    }
    
    @Test
    public void testLastValueByAsOfTime() {
        producer.publishUpdate("TEST", Instant.now().minusSeconds(7200), 100.0);
        producer.publishUpdate("TEST", Instant.now(), 150.0);
        assertEquals(150.0, service.getLastPrice("TEST").getPayload().get("price"));
    }
    
    @Test
    public void testCancelledBatchesDiscarded() {
        UUID batchId = producer.startBatch();
        producer.uploadChunk(batchId, Arrays.asList(
        		PriceRecordBuilderFactory.builder()
                .id("CANCEL")
                .asOf(Instant.now())
                .price(999.0)
                .build()
        ));
        producer.cancelBatch(batchId);
        assertNull(service.getLastPrice("CANCEL"));
    }
    
    @Test
    public void testResilientToIncorrectOrder() {
        UUID fakeId = UUID.randomUUID();
        try {
            producer.uploadChunk(fakeId, Arrays.asList(
            		PriceRecordBuilderFactory.builder().id("BAD").asOf(Instant.now()).price(1.0).build()));
            fail("Should reject unknown batch");
        } catch (BatchNotFoundException ignored) 
        {
        	
        }
        
        UUID realId = producer.startBatch();
        producer.completeBatch(realId);
        try {
            producer.uploadChunk(realId, Arrays.asList(
            		PriceRecordBuilderFactory.builder().id("BAD2").asOf(Instant.now()).price(2.0).build()));
            fail("Should reject post-complete");
        } catch (BatchNotFoundException ignored) {
        	
        }
    }
    
    // FIXED HELPER: Creates records with predictable latest values
    private List<PriceRecord> createTestRecords(int count) {
        List<PriceRecord> records = new ArrayList<>();
        Instant baseTime = Instant.now();
        String[] symbols = {"AAPL", "GOOG", "MSFT"};
        for (int i = 0; i < count; i++) {
            records.add(PriceRecordBuilderFactory.builder()
                .id(symbols[i % 3])
                .asOf(baseTime.plusSeconds(i))  // Increasing asOf → later wins
                .price((double)i)
                .build());
        }
        return records;
    }
}

